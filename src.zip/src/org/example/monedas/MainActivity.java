package org.example.monedas;

import java.util.ArrayList;

import org.example.monedas.dummy.DummyContent;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {

	protected static boolean soundMute = false;

	public static int repetitions = 2;
	public static int secBagBroke = 8;
	public static int secBagShake = 4;
	public static int secReward = 3;
	
	public static int progress = 0;

	public static int numGame = 0;

	protected static Button bConfig;

	public static ArrayList<Integer> myListPig  = new ArrayList<Integer>();
	public static ArrayList<Integer> myListMoneyBag  = new ArrayList<Integer>();
	public static ArrayList<Integer> myListMoneyBagShake  = new ArrayList<Integer>();
	public static ArrayList<Boolean> myListSuccessfulGames  = new ArrayList<Boolean>();
	public static Integer clicksPigTotal = 0;
	public static Integer clicksMoneyBagTotal = 0;
	public static Integer clicksMoneyBagShakeTotal = 0;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_menu);
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);

		bConfig = (Button) findViewById(R.id.button2);
		bConfig.setText(bConfig.getText() +
		"(" + repetitions + ")" +
		"(" + secBagShake + ")" +
		"(" + secBagBroke + ")" +
		"(" + secReward + ")");
	}

	public void startGame (View view){

		Intent i = new Intent(this, GameActivity.class);

		startActivity(i);
	}

	public void startConfig (View view){
		
		Intent i = new Intent(this, ConfigActivity.class);

		startActivity(i);
	}

	public void startStatistics (View view){

		if(!DummyContent.ITEMS.isEmpty()){

			Intent i = new Intent(this, StatisticListActivity.class);

			startActivity(i);

		}else{

			Intent i = new Intent(this, NoStatistics.class);

			startActivity(i);
		}
	}
	
	public void startAbout (View view){

		Intent i = new Intent(this, AboutActivity.class);

		startActivity(i);
	}

	public void saveStats (View view){
		if(!isExternalStorageWritable()){
			Toast.makeText(this, "El almacenamiento del dispositivo no est� disponible", Toast.LENGTH_SHORT).show();
		}else if(DummyContent.ITEMS.isEmpty()){
			// There is no stats yet
			Toast.makeText(this, "No hay estad�sticas que guardar", Toast.LENGTH_SHORT).show();
		}else{
			// Save stats
			Toast.makeText(this, "Estad�sticas guardadas", Toast.LENGTH_SHORT).show();
			SaveStats.saveData();
		}
	}

	public boolean isExternalStorageWritable() {
	    String state = Environment.getExternalStorageState();
	    if (Environment.MEDIA_MOUNTED.equals(state)) {
	        return true;
	    }
	    return false;
	}

	public void mute(View view) {

		if (soundMute == false) {
			view.setBackgroundResource(R.drawable.sonido2); 	// Cambio el fondo del bot�n
			soundMute = true;									// Cambio el valor de la variable de estado
			Toast.makeText(this, "M�sica en minijuego OFF", Toast.LENGTH_SHORT).show();
		} else {
			view.setBackgroundResource(R.drawable.sonido1);		// Cambio el fondo del bot�n
			soundMute = false;									// Cambio el valor de la variable de estado
			Toast.makeText(this, "M�sica en minijuego ON", Toast.LENGTH_SHORT).show();
		}
	}
	
	@Override
    public void onBackPressed() {
		new AlertDialog.Builder(this)
	    .setTitle("Salir de la aplicaci�n")
	    .setMessage("�Est� seguro?")
	    .setPositiveButton("S�", new DialogInterface.OnClickListener() {
	        public void onClick(DialogInterface dialog, int which) {
	            finish();
	        }
	     })
	    .setNegativeButton("No", new DialogInterface.OnClickListener() {
	        public void onClick(DialogInterface dialog, int which) { 
	            // do nothing
	        }
	     })
	     .show();
    }

	@Override
	protected void onStart() {
		super.onStart();
	}

	@Override
	protected void onResume() {
		super.onResume();
	}

	@Override
	protected void onPause() {
		super.onPause();
	}

	@Override
	protected void onStop() {
		super.onStop();
	}

	@Override
	protected void onRestart() {
		super.onRestart();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
	}
}