package org.example.monedas;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;

public class InterludeGame extends Activity {
	
	private MediaPlayer mp;

	private boolean backPressed = false;

	private InterludeView interludeView;

	Intent intGame;

	public static long timeToFinish;

	private static int musicFlowB; 										// Sound when bubble is touched
	private static SoundPool spBlop;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_interlude);
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);		// Both ways in landscape
		timeToFinish = SystemClock.elapsedRealtime();
		interludeView = (InterludeView) findViewById(R.id.InterludeView);
		interludeView.setPadre(this);
		interludeView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LOW_PROFILE);		// This line hide navigation bar
		spBlop = new SoundPool(1, AudioManager.STREAM_MUSIC, 0);
		musicFlowB = spBlop.load(this, R.raw.blop, 1);
		
		if(!MainActivity.soundMute){
			mp = MediaPlayer.create(this, R.raw.song_menu);					// Creating a MediaPlayer with our song
			mp.start();														// Playing the music
			mp.setLooping(true);
		}
		intGame = new Intent(this, GameActivity.class);
	}

	public static void blop(){
		spBlop.play(musicFlowB, 1, 1, 0, 0, 1);
	}

	@Override
	protected void onPause(){
		super.onPause();
		if(!MainActivity.soundMute){
			mp.stop();
			mp.release();	
		}
		mp = null;
		interludeView.getCDT().cancel();
		spBlop.release();
		finish();
		if(backPressed || !interludeView.getExit()){
			MainActivity.numGame = 0;
			MainActivity.clicksPigTotal = 0;
			MainActivity.clicksMoneyBagTotal = 0;
			MainActivity.clicksMoneyBagShakeTotal = 0;
			MainActivity.progress = 0;
		}
	}

	@Override
    public void onBackPressed() {
		new AlertDialog.Builder(this)
	    .setTitle("Salir del juego")
	    .setMessage("�Est� seguro?")
	    .setPositiveButton("S�", new DialogInterface.OnClickListener() {
	        public void onClick(DialogInterface dialog, int which) {
	            backPressed = true;
	            mp.release();
	            spBlop.release();
	            finish();
	        }
	     })
	    .setNegativeButton("No", new DialogInterface.OnClickListener() {
	        public void onClick(DialogInterface dialog, int which) { 
	            // do nothing
	        }
	     })
	     .show();
    }
}