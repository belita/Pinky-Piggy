package org.example.monedas;

import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.CountDownTimer;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class InterludeView extends View{

	//Rect rectan;
	private Vector<Bubble> Bubbles;
	private int numBubbles = 15, numBubblesTemp = 15;
	boolean exit = false;

	private Drawable bar;

	private Activity padre;
	Intent intNextGame;
	CountDownTimer cdt1;
	TimerTask tt;
	Timer t;

	// How long we want to process changes
	protected static int PERIODO_PROCESO = 30;

	// When made last process
	protected static long ultimoProceso = 0;
	protected static long time = 30000;
	private long period = time;

	public InterludeView(Context context, AttributeSet attrs) {
		super(context, attrs);
		
		intNextGame = new Intent(context, GameActivity.class);


		Bubbles = new Vector<Bubble>();

		bar = getResources().getDrawable(R.drawable.marco);

		for (int i = 0; i < numBubbles; i++) {

			Drawable drawableBubble;

			double dof1 = Math.random()*10;
			int d1 = (int) dof1;
			if(d1 >= 0 && d1 <= 3){
				drawableBubble = context.getResources().getDrawable(R.drawable.bubble33);
			}else if(d1 > 3 && d1 <= 6){
				drawableBubble = context.getResources().getDrawable(R.drawable.bubble66);
			}else {
				drawableBubble = context.getResources().getDrawable(R.drawable.bubble100);
			}

			final Bubble bub = new Bubble(context, this, drawableBubble);
			Bubbles.add(bub);
		}

		double dof = Math.random()*10;
		int d = (int) dof;
		if(d >= 0 && d <= 3){
			time = 30000;
		}else if(d > 3 && d <= 6){
			time = 60000;
		}else {
			time = 90000;
		}
		period = time;
		
		t = new Timer();
		tt = new TimerTask() {
			
			@Override
			public void run() {
				long ahora = System.currentTimeMillis();

				// Do nothing if process period has not past

				if (InterludeView.ultimoProceso + InterludeView.PERIODO_PROCESO > ahora) {
					return;
				}

				// Real-time execution

				double factor = (ahora - InterludeView.ultimoProceso) / InterludeView.PERIODO_PROCESO;
				InterludeView.ultimoProceso = ahora;

				// Updating bubble's position

				for (Bubble bubble : Bubbles) {
					if(bubble.getDrawable() != null){
						bubble.incrementPos(factor);
					}
				}
			}
		};
		t.schedule(tt, 0, 10);
		
		cdt1 = new CountDownTimer(time, period) {
			
			@Override
			public void onTick(long millisUntilFinished) {}
			
			@Override
			public void onFinish() {
				tt.cancel();
				exit();
			}
		}.start();
/*
		cdt1 = new CountDownTimer(time, period) {

			@Override
			public void onTick(long millisUntilFinished) {

				long ahora = System.currentTimeMillis();

				// Do nothing if process period has not past

				if (InterludeView.ultimoProceso + InterludeView.PERIODO_PROCESO > ahora) {
					return;
				}

				// Real-time execution

				double factor = (ahora - InterludeView.ultimoProceso) / InterludeView.PERIODO_PROCESO;
				InterludeView.ultimoProceso = ahora;

				// Updating bubble's position

				for (Bubble bubble : InterludeView.Bubbles) {
					bubble.incrementPos(factor);
				}
			}

			@Override
			public void onFinish() {
				exit();
			}
		}.start();
*/
	}

	@Override
	public synchronized boolean onTouchEvent(MotionEvent event){
		super.onTouchEvent(event);
		int ix = (int) event.getX();
		int iy = (int) event.getY();
		if(event.getAction() == MotionEvent.ACTION_DOWN){
			//ArrayList<Bubble> toRemove = new ArrayList<Bubble>();
			//ArrayList<Bubble> toAdd = new ArrayList<Bubble>();
			for (Bubble myBubble : Bubbles) {
				if(myBubble.getDrawable() != null &&
						myBubble.getDrawable().getBounds().contains(ix, iy) &&
						ix > 110 &&
						ix < 1180 &&
						iy > 75 &&
						iy < 685){
					Drawable d = myBubble.getDrawable();
					myBubble.setDrawable(null);
					//Bubbles.remove(myBubble);
					//toRemove.add(myBubble);
					InterludeGame.blop();
					numBubbles--;
					if((numBubblesTemp - numBubbles) == 2){
						myBubble.setIncX((Math.random() - 0.5) * 8);
						while(myBubble.getIncX() == 0) {
							myBubble.setIncX((Math.random() - 0.5) * 8);
						}
						myBubble.setIncY((Math.random() - 0.5) * 8);
						while(myBubble.getIncY() == 0) {
							myBubble.setIncY((Math.random() - 0.5) * 8);
						}
						myBubble.setPosX(Math.random() * (1170 - myBubble.getWi()));
						if(myBubble.getPosX() < 120){
							myBubble.setPosX(120);
						}
						myBubble.setPosY(Math.random() * (675 - myBubble.getHe()));
						if(myBubble.getPosY() < 85){
							myBubble.setPosY(85);
						}
						myBubble.setDrawable(d);
						//Bubbles.add(myBubble);
						//toAdd.add(myBubble);
						numBubbles++;
						numBubblesTemp = numBubbles;
					}
				}
			}
			//Bubbles.removeAll(toRemove);
			//Bubbles.addAll(toAdd);
			for(int i = 0; i < Bubbles.size(); i++){
				if(Bubbles.get(i).getDrawable() != null){
					break;
				}else if(i == (Bubbles.size() - 1)){
					tt.cancel();
					exit();
				}
			}
		}
		return true;
	}

	@Override
	protected void onSizeChanged(int width, int height, int width_before, int height_before) {

		super.onSizeChanged(width, height, width_before, height_before);

		for (Bubble bubble : Bubbles) {
			bubble.setPosX(Math.random() * (1218 - bubble.getWi()));
			if(bubble.getPosX() < 64){
				bubble.setPosX(64);
			}
			bubble.setPosY(Math.random() * (724 - bubble.getHe()));
			if(bubble.getPosX() < 37){
				bubble.setPosY(37);
			}
		}

		ultimoProceso = System.currentTimeMillis();
	}

	@Override
	protected synchronized void onDraw(Canvas canvas) {

		super.onDraw(canvas);
		
		// Drawing elements in screen

		for (Bubble bubble : Bubbles) {

			bubble.drawGraphic(canvas);

		}
		bar.setBounds(0, 0, getWidth(), getHeight());
		bar.draw(canvas);
	}

	public void setPadre(Activity padre) {
		this.padre = padre;
	}

	private void exit() {
		exit = true;
		padre.finish();
		padre.startActivity(intNextGame);
	}

	protected CountDownTimer getCDT(){
		return cdt1;
	}

	protected boolean getExit(){
		return exit;
	}
}