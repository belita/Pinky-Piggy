package org.example.monedas;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;

public class ConfigActivity extends Activity {

	SeekBar sbRep, sbSecBag, sbSecRew, sbSecShk;
	TextView tRep,tBag,tRew, tShk;
	int repetitions, secBagBroken, secBagShaken, secReward;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_config);
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);		// Both ways in landscape

		sbRep = (SeekBar) findViewById(R.id.seekBar1);
		sbSecBag = (SeekBar) findViewById(R.id.seekBar2);
		sbSecRew = (SeekBar) findViewById(R.id.seekBar3);
		sbSecShk = (SeekBar) findViewById(R.id.seekBar4);
		tRep = (TextView) findViewById(R.id.textView1);
		tBag = (TextView) findViewById(R.id.textView2);
		tRew = (TextView) findViewById(R.id.textView3);
		tShk = (TextView) findViewById(R.id.textView4);

		repetitions = MainActivity.repetitions;
		secBagBroken = MainActivity.secBagBroke;
		secReward = MainActivity.secReward;
		secBagShaken = MainActivity.secBagShake;

		sbRep.setProgress(repetitions - 1);
		sbSecBag.setProgress(secBagBroken - 4);
		sbSecRew.setProgress(secReward - 1);
		sbSecShk.setProgress(secBagShaken - 2);

		tRep.setText("Repeticiones del juego = " + MainActivity.repetitions);
		tBag.setText("Segundos para que se rompa la bolsa = " + MainActivity.secBagBroke);
		tRew.setText("Segundos para recoger la recompensa = " + MainActivity.secReward);
		tShk.setText("Duraci�n (segundos) del agite de la bolsa = " + MainActivity.secBagShake);

		sbRep.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {

			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {}

			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {}
			
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
				progress++;
				repetitions = progress;
				tRep.setText("Repeticiones del juego = " + repetitions);
			}
		});

		sbSecShk.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
			
			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {}
			
			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {}
			
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
				if(secBagBroken >= (progress + 2) + 2){
					progress = progress + 2;
					secBagShaken = progress;
				}else{
					progress = progress + 2;
					secBagShaken = progress;
					sbSecBag.setProgress(secBagShaken - 2);
				}
				tShk.setText("Duraci�n (segundos) del agite de la bolsa = " + secBagShaken);
			}
		});

		sbSecBag.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
			
			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {}
			
			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {}
			
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
				if((progress + 4) >= secBagShaken + 2){
					progress = progress + 4;
					secBagBroken = progress;
				}else{
					progress = progress + 4;
					secBagBroken = progress;
					sbSecShk.setProgress(secBagBroken - 4);
				}
				tBag.setText("Segundos para que se rompa la bolsa = " + secBagBroken);
			}
		});

		sbSecRew.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {

			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {}
			
			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {}
			
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
				progress++;
				secReward = progress;
				tRew.setText("Segundos para recoger la recompensa = " + secReward);
			}
		});
	}

	public void cancel(View view) {
		Toast.makeText(this,"Cancelaste", Toast.LENGTH_LONG).show();		// Muestro un toast para indicar que se cancel�
		this.finish();														// Cierro la ventana (dialog)
	}

	public void confirm(View view){
		if(secBagBroken - secBagShaken >= 2){
			MainActivity.repetitions = repetitions;
			MainActivity.secBagBroke = secBagBroken;
			MainActivity.secReward = secReward;
			MainActivity.secBagShake = secBagShaken;
			this.finish();
			MainActivity.bConfig.setText("Configuraci�n " +
			"(" + MainActivity.repetitions + ")" +
			"(" + MainActivity.secBagShake + ")" +
			"(" + MainActivity.secBagBroke + ")" +
			"(" + MainActivity.secReward + ")");
			
		}else{
			Toast.makeText(this,
					"Los segundos para que se rompa la bolsa deben ser como m�nimo 2 segundos m�s que la duraci�n del agite",
					Toast.LENGTH_LONG).show();
		}
	}
}