package org.example.monedas;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.CycleInterpolator;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

public class GameActivity extends Activity {

	private Boolean success = false;
	private boolean points = false, bagBroken = false, bagShake = false,
			rewarded = false, getPoints = false, back = false, exitGame = false, canClickPinkPig = false;
	private long timeBagShake, timeBagBroke, total;
	Handler handler = new Handler();

	CountDownTimer cdt;
	Animation shake,drop;

	public Integer clicksPig, clicksMoneyBag, clicksMoneyBagShake;

	private Intent intInterlude, intNameStats;

	ImageView pig, pigBYN, moneyBag, moneyBagBAW, coinsAmount, coin, redCross;
	ProgressBar pb;

	private int musicFlowCD, musicFlowCS, musicFlowP, musicFlowBB, musicFlowT, musicFlowB, musicFlowGO;
	private SoundPool spCoinsDrop, spCoinsShake, spPig, spMoneyBagBroken, spTachan, spBlop, spGameOver;

	@SuppressLint("InlinedApi")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_game);
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);		// Both ways in landscape
		View v = findViewById(R.id.relative1);							// This and next line hide navigation bar
		v.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LOW_PROFILE);

		total = 5000 + MainActivity.secBagBroke*1000 + MainActivity.secReward*1000;
		timeBagBroke = total - MainActivity.secBagBroke*1000;
		timeBagShake = timeBagBroke + MainActivity.secBagShake*1000;

		coin = (ImageView) findViewById(R.id.ImageView03);
		coinsAmount = (ImageView) findViewById(R.id.ImageView02);
		moneyBag = (ImageView) findViewById(R.id.ImageView01);
		pigBYN = (ImageView) findViewById(R.id.imageView1);
		pig = (ImageView) findViewById(R.id.imageView2);
		redCross = (ImageView) findViewById(R.id.ImageView04);
		moneyBagBAW = (ImageView) findViewById(R.id.ImageView05);

		pb = (ProgressBar) findViewById(R.id.progressbar1);
		pb.setMax(MainActivity.repetitions);
		pb.setProgress(MainActivity.progress);

		clicksPig = 0;
		clicksMoneyBag = 0;
		clicksMoneyBagShake = 0;
		MainActivity.myListPig.add(MainActivity.numGame, clicksPig);
		MainActivity.myListMoneyBag.add(MainActivity.numGame, clicksMoneyBag);
		MainActivity.myListMoneyBagShake.add(MainActivity.numGame, clicksMoneyBagShake);

		CycleInterpolator c1 = new CycleInterpolator(MainActivity.secBagShake);
		shake = AnimationUtils.loadAnimation(this, R.anim.shake);
		shake.setDuration(MainActivity.secBagShake*1000);
		shake.setInterpolator(c1);
		drop = AnimationUtils.loadAnimation(this, R.anim.linear);

		spGameOver = new SoundPool(1, AudioManager.STREAM_MUSIC, 0);
		musicFlowGO = spGameOver.load(this, R.raw.gameover, 1);
		spCoinsDrop = new SoundPool(1, AudioManager.STREAM_MUSIC, 0);
		musicFlowCD = spCoinsDrop.load(this, R.raw.coin_drop, 1);
		spCoinsShake = new SoundPool(8, AudioManager.STREAM_MUSIC, 0);
		musicFlowCS = spCoinsShake.load(this, R.raw.coins_shake, 1);
		spPig = new SoundPool(8, AudioManager.STREAM_MUSIC, 0);
		musicFlowP = spPig.load(this, R.raw.pig_sound, 1);
		spMoneyBagBroken = new SoundPool(1, AudioManager.STREAM_MUSIC, 0);
		musicFlowBB = spMoneyBagBroken.load(this, R.raw.velcro1, 1);
		spTachan = new SoundPool(1, AudioManager.STREAM_MUSIC, 0);
		musicFlowT = spTachan.load(this, R.raw.tachan, 1);
		spBlop = new SoundPool(1, AudioManager.STREAM_MUSIC, 0);
		musicFlowB = spBlop.load(this, R.raw.blop, 1);

		int ng = MainActivity.numGame + 1;
		Toast.makeText(this, "Juego " + ng, Toast.LENGTH_SHORT).show();

		intInterlude = new Intent(this, InterludeGame.class);
		intNameStats = new Intent(this, NameStatActivity.class);

		cdt = new CountDownTimer(total, 1000) {

			@Override
			public void onTick(long millisUntilFinished) {
				if(!bagShake && millisUntilFinished < timeBagShake){		// Start shaking bag
					bagShake = true;
					spMoneyBagBroken.play(musicFlowBB, 1, 1, 0, 0, 1);			// Velcro sound, money bag broking
					moneyBagBAW.setVisibility(View.GONE);						// MoneyBag B&W dissapear
					moneyBag.setVisibility(View.VISIBLE);						// Color Bag appear
					pigBYN.setVisibility(View.GONE);							// Pig B&W dissappear but clickable
					pig.setVisibility(View.VISIBLE);							// Pink pig appear
					moneyBag.startAnimation(shake);
				}
				if(!bagBroken && millisUntilFinished < timeBagBroke){		// Bag dissapear and time to get reward
					bagBroken = true;
					canClickPinkPig = true;
					spBlop.play(musicFlowB, 1, 1, 0, 0, 1);						// Blop sound
					pigBYN.setVisibility(View.GONE);							// Pig B&W dissapear
					pig.setOnClickListener(new OnClickListener() {
						@Override
						public void onClick(View v) {
							getReward(v);
						}
					});
					moneyBag.setVisibility(View.GONE);							// Money bag dissapear
					coinsAmount.setVisibility(View.VISIBLE);					// Coins amount appear
				}
				if(millisUntilFinished < 5000 && !rewarded && !getPoints){	// Red cross and no points
					getPoints = true;
					redCross.setVisibility(View.VISIBLE);
					pig.setClickable(false);
					spGameOver.play(musicFlowGO, 1, 1, 0, 0, 1);
				}
				if(rewarded && !points){									// Getting reward :)
					points = true;
					pb.incrementProgressBy(1);
					spBlop.play(musicFlowB, 1, 1, 0, 0, 1);
					MainActivity.progress++;
				}
			}

			@Override
			public void onFinish() {
				MainActivity.myListSuccessfulGames.add(MainActivity.numGame, success);
				MainActivity.myListPig.add(MainActivity.numGame, clicksPig);
				MainActivity.myListMoneyBag.add(MainActivity.numGame, clicksMoneyBag);
				MainActivity.myListMoneyBagShake.add(MainActivity.numGame, clicksMoneyBagShake);
				MainActivity.numGame++;
				exitGame = true;
				spBlop.release();
				spCoinsDrop.release();
				spCoinsShake.release();
				spGameOver.release();
				spMoneyBagBroken.release();
				spPig.release();
				spTachan.release();
				finish();
				if(MainActivity.repetitions != MainActivity.numGame){			// If any repetition, play interlude
					startActivity(intInterlude);
				}else{
					startActivity(intNameStats);
				}
			}
		}.start();
	}

	public void clickPig(View view){
		if(!bagBroken){
			spPig.play(musicFlowP, 1, 1, 0, 0, 1);
			MainActivity.clicksPigTotal++;
			clicksPig++;
		}
	}

	public void clickMoney(View view){
		if(!bagShake){
			spCoinsShake.play(musicFlowCS, 1, 1, 0, 0, 1);
			MainActivity.clicksMoneyBagTotal++;
			clicksMoneyBag++;
		}else{
			spCoinsShake.play(musicFlowCS, 1, 1, 0, 0, 1);
			MainActivity.clicksMoneyBagShakeTotal++;
			clicksMoneyBagShake++;
		}
	}

	public void getReward(View view){
		if(canClickPinkPig){
			canClickPinkPig = false;
			getPoints = true;
			success = true;
			spTachan.play(musicFlowT, 1, 1, 0, 0, 1);
			pig.setClickable(false);
			coinsAmount.setVisibility(View.GONE);
			coin.setVisibility(View.VISIBLE);
			coin.startAnimation(drop);
			handler.postDelayed(new Runnable() {
				public void run() {
					spCoinsDrop.play(musicFlowCD, 1, 1, 0, 0, 1);
					coin.setVisibility(View.GONE);
					rewarded = true;
				}
		    }, 1500);
		}
	}

	@Override
    public void onBackPressed() {
		new AlertDialog.Builder(this)
	    .setTitle("Salir del juego")
	    .setMessage("�Est� seguro?")
	    .setPositiveButton("S�", new DialogInterface.OnClickListener() {
	        public void onClick(DialogInterface dialog, int which) {
	            back = true;
	            spBlop.release();
				spCoinsDrop.release();
				spCoinsShake.release();
				spGameOver.release();
				spMoneyBagBroken.release();
				spPig.release();
				spTachan.release();
	        	finish();
	        }
	     })
	    .setNegativeButton("No", new DialogInterface.OnClickListener() {
	        public void onClick(DialogInterface dialog, int which) { 
	            // do nothing
	        }
	     })
	     .show();
    }

	@Override
	protected void onPause(){
		super.onPause();
		cdt.cancel();
		spBlop.release();
		spCoinsDrop.release();
		spCoinsShake.release();
		spGameOver.release();
		spMoneyBagBroken.release();
		spPig.release();
		spTachan.release();
		finish();
		if(back || !exitGame){
			MainActivity.numGame = 0;
			MainActivity.clicksPigTotal = 0;
			MainActivity.clicksMoneyBagTotal = 0;
			MainActivity.progress = 0;
		}
	}
}