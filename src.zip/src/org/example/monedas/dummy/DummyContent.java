package org.example.monedas.dummy;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.example.monedas.MainActivity;

/**
 * Helper class for providing sample content for user interfaces created by
 * Android template wizards.
 * <p>
 */
public class DummyContent {

	private static Integer i = 1;
	private static Integer i2 = 1;

	/**
	 * An array of sample (dummy) items.
	 */
	public static List<DummyItem> ITEMS = new ArrayList<DummyItem>();

	/**
	 * A map of sample (dummy) items, by ID.
	 */
	public static Map<String, DummyItem> ITEM_MAP = new HashMap<String, DummyItem>();

	public static void createDummyItem(){
		for(int n = 1; n <= MainActivity.repetitions; n++){
			addItem(new DummyItem(
					(i2++).toString(),
					Integer.toString(n),
					MainActivity.myListMoneyBag.get(n-1).toString(),
					MainActivity.myListMoneyBagShake.get(n-1).toString(),
					MainActivity.myListPig.get(n-1).toString(),
					MainActivity.myListSuccessfulGames.get(n-1)));
		}
		addItem(new DummyItem(
				"Total" + i++,
				"Total",
				MainActivity.clicksMoneyBagTotal.toString(),
				MainActivity.clicksMoneyBagShakeTotal.toString(),
				MainActivity.clicksPigTotal.toString(), true));
	}

	public static void createDummyItem(String name){
		for(int n = 1; n <= MainActivity.repetitions; n++){
			addItem(new DummyItem(
					(i2++).toString(),
					Integer.toString(n),
					MainActivity.myListMoneyBag.get(n-1).toString(),
					MainActivity.myListMoneyBagShake.get(n-1).toString(),
					MainActivity.myListPig.get(n-1).toString(),
					MainActivity.myListSuccessfulGames.get(n-1),
					name));
		}
		addItem(new DummyItem(
				"Total " + i++,
				"Total",
				MainActivity.clicksMoneyBagTotal.toString(),
				MainActivity.clicksMoneyBagShakeTotal.toString(),
				MainActivity.clicksPigTotal.toString(), true, name));
	}

	private static void addItem(DummyItem item) {
		ITEMS.add(item);
		ITEM_MAP.put(item.id, item);
	}

	/**
	 * A dummy item representing a piece of content.
	 */
	public static class DummyItem {

		public String id;
		public String numGame;
		public String clicksBag;
		public String clicksBagShake;
		public String clicksPig;
		public Boolean success;
		public String name = null;

		public DummyItem(String id, String numGame, String clicksBag,
				String clicksBagShake, String clicksPig, boolean b) {
			this.id = id;
			this.numGame = numGame;
			this.clicksBag = clicksBag;
			this.clicksBagShake = clicksBagShake;
			this.clicksPig = clicksPig;
			this.success = b;
		}
		
		public DummyItem(String id, String numGame, String clicksBag,
				String clicksBagShake, String clicksPig, boolean b, String name) {
			this.id = id;
			this.numGame = numGame;
			this.clicksBag = clicksBag;
			this.clicksBagShake = clicksBagShake;
			this.clicksPig = clicksPig;
			this.success = b;
			this.name = name;
		}

		@Override
		public String toString() {
			if(name == null){
				return "Juego " + numGame;				
			}else{
				return name + " " + numGame;
			}
		}
		
		public String getId(){
			return id;
		}
		
		public String getClicksBag(){
			return clicksBag;
		}
		
		public String getClicksBagShake(){
			return clicksBagShake;
		}
		
		public String getClicksPig(){
			return clicksPig;
		}
		
		public String getName(){
			return name;
		}
		
		public String getNumGame(){
			return numGame;
		}
		
		public Boolean getSuccess(){
			return success;
		}
	}
}