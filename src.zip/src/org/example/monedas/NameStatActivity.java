package org.example.monedas;

import org.example.monedas.dummy.DummyContent;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class NameStatActivity extends Activity {

	private Button but;
	private EditText edit;
	private Intent intStats;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_name_stat);
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);		// Both ways in landscape

		intStats = new Intent(this, StatisticListActivity.class);
		edit = (EditText) findViewById(R.id.editText5);
		but = (Button) findViewById(R.id.button1);
	}

	public void showStats(View view){
		String str = edit.getText().toString().trim();
		if(str.compareTo("") == 0){
			DummyContent.createDummyItem();
		}else{
			DummyContent.createDummyItem(str);
		}
		finish();
		startActivity(intStats);
		MainActivity.numGame = 0;
		MainActivity.clicksPigTotal = 0;
		MainActivity.clicksMoneyBagTotal = 0;
		MainActivity.clicksMoneyBagShakeTotal = 0;
		MainActivity.progress = 0;
	}

	@Override
    public void onBackPressed() {
		showStats(but);
    }
}