package org.example.monedas;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.os.Bundle;

public class NoStatistics extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_no_statistics);
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);		// Both ways in landscape
	}
}