package org.example.monedas;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.ImageView;

class Bubble extends ImageView {
	
	private Drawable drawable; // Image we'll draw

	private double posX, posY; // Position

	private double incX, incY; // Movement speed

	private View view; // Where Graphic will be painted

	private int width, height; // Dimensiones de la imagen

	public static final int MAX_SPEED = 20;

	public Bubble(Context c){
		super(c);
	}

	public Bubble(Context context, View view, Drawable drawable) {
		super(context);

		this.view = view;

		this.drawable = drawable;

		width = drawable.getIntrinsicWidth();

		height = drawable.getIntrinsicHeight();

		incY = (Math.random() - 0.5) * 8;
		while(incX == 0) {
			incX = (Math.random() - 0.5) * 8;
		}
		
		incY = (Math.random() - 0.5) * 8;
		while(incY == 0) {
			incY = (Math.random() - 0.5) * 8;
		}
	}

	public void drawGraphic(Canvas canvas) {

		if(drawable != null){
			canvas.save();
	
			int x = (int) (posX + width / 2);
	
			int y = (int) (posY + height / 2);
	
			drawable.setBounds((int) posX, (int) posY, (int) posX + width, (int) posY + height);
	
			drawable.draw(canvas);
	
			canvas.restore();
	
			int rInval = (int) Math.hypot(width, height) / 2 + MAX_SPEED;
	
			view.invalidate(x - rInval, y - rInval, x + rInval, y + rInval);
		}

	}

	public void incrementPos(double factor) {

		posX += incX * factor;

		// If get out of the screen, re-draw
		
		if (posX < 110-width) {					// Bubble hide at left
			posX = 1180;
		}

		if (posX > 1180) {	// Bubble hide at right
			posX = 110-width;
		}

		posY += incY * factor;

		if (posY < 75-height) {					// Bubble hide at top
			posY = 685;
		}

		if (posY > 685) {	// Bubble hide at bottom
			posY = 75-height;
		}
	}

	@Override
	public Drawable getDrawable() {
		return drawable;
	}

	public void setDrawable(Drawable drawable) {
		this.drawable = drawable;
	}

	public double getPosX() {
		return posX;
	}

	public void setPosX(double posX) {
		this.posX = posX;
	}

	public double getPosY() {
		return posY;
	}

	public void setPosY(double posY) {
		this.posY = posY;
	}

	public double getIncX() {
		return incX;
	}

	public void setIncX(double incX) {
		this.incX = incX;
	}

	public double getIncY() {
		return incY;
	}

	public void setIncY(double incY) {
		this.incY = incY;
	}

	public int getWi() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHe() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public View getView() {
		return view;
	}

	public void setView(View view) {
		this.view = view;
	}

	public static int getMaxSpeed() {
		return MAX_SPEED;
	}
}