package org.example.monedas;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class SeriousGamesActivity extends Activity {

	private Animation anim;
	private ImageView sgLogo;
	private MediaPlayer mp;
	Handler handler;
	Intent i;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_seriousgames);
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);		// Both ways in landscape

		anim = AnimationUtils.loadAnimation(this, R.anim.sg);
		sgLogo = (ImageView) findViewById(R.id.imageView1);
		mp = MediaPlayer.create(this, R.raw.intro);
		mp.start();
		handler = new Handler();
		i = new Intent(this, MainActivity.class);
	}

	@Override
    protected void onResume() {
        super.onResume();
        sgLogo.setVisibility(View.VISIBLE);
        sgLogo.startAnimation(anim);
        handler.postDelayed(new Runnable() {
	         public void run() {
	        	 sgLogo.setVisibility(View.GONE);
	        	 startActivity(i);
	        	 finish();
	         }
	    }, 3000);
    }

	@Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        finish();
	}
	
	@Override
	protected void onPause(){
		super.onPause();
		//spSG.release();
		mp.release();
	}
}